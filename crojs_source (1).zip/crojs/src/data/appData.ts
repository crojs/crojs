export interface AppData {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  image: string;
  category: string;
  rating: number;
  size: string;
  version: string;
  developer: string;
  features: string[];
}

export const movieApps: AppData[] = [
  {
    id: 'moviehd',
    name: 'MovieHD',
    description: 'Watch the latest movies and TV shows in HD quality with MovieHD.',
    longDescription: 'MovieHD is a premium streaming application that offers a vast library of movies and TV shows in high definition. With regular updates and new content added daily, you will never run out of entertainment options. The app features an intuitive interface, multiple language support, and the ability to download content for offline viewing.',
    image: 'https://via.placeholder.com/600x400?text=MovieHD',
    category: 'Movies & TV',
    rating: 4.8,
    size: '25MB',
    version: '3.2.1',
    developer: 'MovieHD Team',
    features: [
      'HD and Full HD streaming',
      'Download for offline viewing',
      'Regular content updates',
      'Multiple language support',
      'Chromecast compatibility'
    ]
  },
  {
    id: 'cinemahd',
    name: 'CinemaHD',
    description: 'Experience cinema-quality streaming with the best selection of movies and shows.',
    longDescription: 'CinemaHD brings the cinema experience to your device with ultra-high-definition streaming of the latest movies and TV series. The application offers a clean, ad-free interface with advanced filtering options to help you find exactly what you want to watch. With support for external players and subtitles, CinemaHD provides a complete viewing experience.',
    image: 'https://via.placeholder.com/600x400?text=CinemaHD',
    category: 'Entertainment',
    rating: 4.7,
    size: '30MB',
    version: '2.5.0',
    developer: 'Cinema Plus',
    features: [
      'Ultra HD streaming',
      'Ad-free experience',
      'External player support',
      'Subtitle integration',
      'Favorites and watchlist'
    ]
  },
  {
    id: 'vivatv',
    name: 'VivaTV',
    description: 'Stream live TV channels and on-demand content from around the world.',
    longDescription: 'VivaTV offers both live TV streaming and on-demand content from channels around the world. With over 1000+ channels and a growing library of movies and series, VivaTV is your one-stop entertainment solution. The app features a TV guide, reminder functionality, and the ability to record live broadcasts for later viewing.',
    image: 'https://via.placeholder.com/600x400?text=VivaTV',
    category: 'Live TV',
    rating: 4.5,
    size: '28MB',
    version: '4.1.2',
    developer: 'Viva Media',
    features: [
      'Live TV streaming',
      'On-demand content',
      'TV guide',
      'Recording functionality',
      'Reminder settings'
    ]
  },
  {
    id: 'beetv',
    name: 'BeeTV',
    description: 'Discover and stream thousands of movies and TV shows with BeeTV.',
    longDescription: 'BeeTV is a feature-rich streaming application that provides access to thousands of movies and TV shows. The app uses multiple sources to ensure high availability and offers features like trakt.tv integration for syncing your watching progress across devices. With a beautiful interface and powerful search capabilities, finding and enjoying content has never been easier.',
    image: 'https://via.placeholder.com/600x400?text=BeeTV',
    category: 'Entertainment',
    rating: 4.6,
    size: '22MB',
    version: '3.0.5',
    developer: 'Bee Developers',
    features: [
      'Multiple streaming sources',
      'Trakt.tv integration',
      'Real-debrid support',
      'Auto-play next episode',
      'Advanced search filters'
    ]
  },
  {
    id: 'teatv',
    name: 'TeaTV',
    description: 'Relax and enjoy your favorite content with TeaTV\'s smooth streaming experience.',
    longDescription: 'TeaTV offers a relaxing and enjoyable streaming experience with its vast library of movies and TV shows. The application features a clean, intuitive interface with minimal ads and fast loading times. With support for multiple video qualities and external players, TeaTV adapts to your preferences and network conditions.',
    image: 'https://via.placeholder.com/600x400?text=TeaTV',
    category: 'Movies & TV',
    rating: 4.4,
    size: '26MB',
    version: '10.2.7',
    developer: 'Tea Media',
    features: [
      'Multiple video qualities',
      'Fast loading times',
      'Minimal advertisements',
      'External player support',
      'Bookmark functionality'
    ]
  },
  {
    id: 'onstream',
    name: 'OnStream',
    description: 'Stream content from multiple platforms in one convenient application.',
    longDescription: 'OnStream aggregates content from multiple streaming platforms, allowing you to browse and watch everything in one place. The application features a unified search function, personalized recommendations, and the ability to create custom playlists across platforms. With OnStream, you\'ll never need to switch between apps again.',
    image: 'https://via.placeholder.com/600x400?text=OnStream',
    category: 'Aggregator',
    rating: 4.3,
    size: '32MB',
    version: '2.1.0',
    developer: 'Stream Solutions',
    features: [
      'Multi-platform integration',
      'Unified search',
      'Personalized recommendations',
      'Custom playlists',
      'Watch history synchronization'
    ]
  },
  {
    id: 'hdo',
    name: 'HDO',
    description: 'High-definition streaming with a focus on the latest releases.',
    longDescription: 'HDO specializes in high-definition streaming of the latest movie and TV releases. The application updates its library daily and provides multiple streaming links for each title to ensure availability. With features like auto-play, continue watching, and night mode, HDO offers a comfortable viewing experience at any time.',
    image: 'https://via.placeholder.com/600x400?text=HDO',
    category: 'Movies & TV',
    rating: 4.7,
    size: '24MB',
    version: '5.2.3',
    developer: 'HD Online Team',
    features: [
      'Daily updates',
      'Multiple streaming links',
      'Auto-play functionality',
      'Continue watching',
      'Night mode'
    ]
  },
  {
    id: 'filmplus',
    name: 'FilmPlus',
    description: 'Your plus-one for movie nights with thousands of titles to choose from.',
    longDescription: 'FilmPlus is your companion for movie nights, offering thousands of films across all genres. The application features detailed information about each title, including cast, crew, ratings, and reviews. With its recommendation engine and curated collections, FilmPlus helps you discover new favorites based on your viewing habits.',
    image: 'https://via.placeholder.com/600x400?text=FilmPlus',
    category: 'Movies',
    rating: 4.5,
    size: '27MB',
    version: '3.4.2',
    developer: 'Film+ Studios',
    features: [
      'Extensive movie library',
      'Detailed title information',
      'Recommendation engine',
      'Curated collections',
      'Offline mode'
    ]
  },
  {
    id: 'youcine',
    name: 'YouCine',
    description: 'Personalized cinema experience with content tailored to your preferences.',
    longDescription: 'YouCine creates a personalized cinema experience by learning your preferences and recommending content you\'ll love. The application features an advanced AI that analyzes your viewing habits and ratings to suggest movies and shows that match your taste. With its sleek interface and social features, YouCine makes discovering new content a joy.',
    image: 'https://via.placeholder.com/600x400?text=YouCine',
    category: 'Personalized',
    rating: 4.6,
    size: '29MB',
    version: '2.0.1',
    developer: 'YouMedia',
    features: [
      'AI-powered recommendations',
      'Preference learning',
      'Social sharing',
      'Rating system',
      'Watch parties'
    ]
  },
  {
    id: 'novatv',
    name: 'NovaTV',
    description: 'Discover new and exclusive content not available on mainstream platforms.',
    longDescription: 'NovaTV specializes in new and exclusive content that you won\'t find on mainstream streaming platforms. The application sources independent films, international series, and original productions to provide a unique viewing experience. With its focus on quality over quantity, NovaTV ensures that every title in its library is worth watching.',
    image: 'https://via.placeholder.com/600x400?text=NovaTV',
    category: 'Exclusive',
    rating: 4.4,
    size: '23MB',
    version: '1.8.5',
    developer: 'Nova Entertainment',
    features: [
      'Exclusive content',
      'Independent films',
      'International series',
      'Original productions',
      'Curator recommendations'
    ]
  },
  {
    id: 'flixon',
    name: 'FlixOn',
    description: 'Keep the entertainment flowing with FlixOn\'s seamless streaming experience.',
    longDescription: 'FlixOn provides a seamless streaming experience with its optimized platform that minimizes buffering and maximizes quality. The application adapts to your network conditions and device capabilities to deliver the best possible viewing experience. With features like smart downloads and bandwidth control, FlixOn ensures smooth entertainment even with limited connectivity.',
    image: 'https://via.placeholder.com/600x400?text=FlixOn',
    category: 'Streaming',
    rating: 4.5,
    size: '25MB',
    version: '4.3.0',
    developer: 'Flix Technologies',
    features: [
      'Adaptive streaming',
      'Smart downloads',
      'Bandwidth control',
      'Offline mode',
      'Device synchronization'
    ]
  },
  {
    id: 'showbox',
    name: 'ShowBox',
    description: 'All your favorite shows in one box, updated daily with the latest episodes.',
    longDescription: 'ShowBox focuses on television series, offering a comprehensive library of shows from around the world. The application updates daily with the latest episodes and notifies you when new content from your favorite series is available. With features like season tracking, episode guides, and show recommendations, ShowBox is the ultimate companion for TV enthusiasts.',
    image: 'https://via.placeholder.com/600x400?text=ShowBox',
    category: 'TV Shows',
    rating: 4.7,
    size: '26MB',
    version: '6.1.2',
    developer: 'ShowBox Media',
    features: [
      'Daily episode updates',
      'Show notifications',
      'Season tracking',
      'Episode guides',
      'Show recommendations'
    ]
  },
  {
    id: 'movieboxpro',
    name: 'MovieBoxPro',
    description: 'Professional-grade streaming with premium features for the ultimate experience.',
    longDescription: 'MovieBoxPro offers a professional-grade streaming experience with premium features that elevate your entertainment. The application provides ultra-high-definition content, advanced subtitle customization, and integration with home theater systems. With its VIP subscription option, MovieBoxPro removes all limitations and offers priority access to the latest releases.',
    image: 'https://via.placeholder.com/600x400?text=MovieBoxPro',
    category: 'Premium',
    rating: 4.9,
    size: '35MB',
    version: '7.0.3',
    developer: 'MovieBox Team',
    features: [
      'Ultra HD streaming',
      'Advanced subtitle options',
      'Home theater integration',
      'VIP subscription',
      'Priority access to new releases'
    ]
  }
];
