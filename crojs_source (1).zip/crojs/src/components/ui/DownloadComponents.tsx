import React from 'react';
import { motion } from 'framer-motion';
import { FiDownload, FiClock } from 'react-icons/fi';

interface DownloadButtonProps {
  appName: string;
  onClick: () => void;
}

const DownloadButton: React.FC<DownloadButtonProps> = ({ appName, onClick }) => {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-lg flex items-center justify-center space-x-3 transition-colors shadow-lg"
    >
      <FiDownload size={20} />
      <span className="font-medium">Download {appName}</span>
    </motion.button>
  );
};

interface DownloadTimerProps {
  seconds: number;
  onComplete: () => void;
  isProcessing: boolean;
}

const DownloadTimer: React.FC<DownloadTimerProps> = ({ 
  seconds, 
  onComplete, 
  isProcessing 
}) => {
  const [timeLeft, setTimeLeft] = React.useState(seconds);
  
  React.useEffect(() => {
    if (timeLeft <= 0) {
      onComplete();
      return;
    }
    
    const timer = setTimeout(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [timeLeft, onComplete]);
  
  const progressPercent = ((seconds - timeLeft) / seconds) * 100;
  
  return (
    <div className="w-full">
      {isProcessing ? (
        <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg text-center">
          <div className="flex flex-col items-center space-y-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="text-blue-600"
            >
              <FiClock size={40} />
            </motion.div>
            <p className="text-gray-700 dark:text-gray-300 font-medium">Processing your download...</p>
          </div>
        </div>
      ) : (
        <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg">
          <div className="flex flex-col space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-700 dark:text-gray-300 font-medium">Download starting in:</span>
              <span className="text-blue-600 font-bold">{timeLeft}s</span>
            </div>
            
            <div className="w-full bg-gray-300 dark:bg-gray-700 rounded-full h-2.5">
              <motion.div 
                className="bg-blue-600 h-2.5 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Please wait while we prepare your download...
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export { DownloadButton, DownloadTimer };
