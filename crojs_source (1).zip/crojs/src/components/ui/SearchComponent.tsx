import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiSearch, FiX, FiArrowRight } from 'react-icons/fi';
import { movieApps, AppData } from '../../data/appData';

interface SearchComponentProps {
  onSearch?: (query: string) => void;
  className?: string;
  placeholder?: string;
  showInHeader?: boolean;
}

const SearchComponent: React.FC<SearchComponentProps> = ({
  onSearch,
  className = '',
  placeholder = 'Search for apps...',
  showInHeader = false
}) => {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [searchResults, setSearchResults] = useState<AppData[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Handle clicks outside of search component to close results
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  useEffect(() => {
    // Perform search as user types
    if (query.trim().length >= 2) {
      const filtered = movieApps.filter(app => 
        app.name.toLowerCase().includes(query.toLowerCase()) ||
        app.description.toLowerCase().includes(query.toLowerCase()) ||
        app.category.toLowerCase().includes(query.toLowerCase()) ||
        app.developer.toLowerCase().includes(query.toLowerCase()) ||
        app.features.some(feature => feature.toLowerCase().includes(query.toLowerCase()))
      );
      setSearchResults(filtered);
    } else {
      setSearchResults([]);
    }
  }, [query]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && onSearch) {
      onSearch(query);
      setIsFocused(false);
    }
  };
  
  const clearSearch = () => {
    setQuery('');
    setSearchResults([]);
  };
  
  return (
    <div 
      ref={searchRef}
      className={`relative ${className}`}
    >
      <motion.form 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        onSubmit={handleSubmit}
        className={`relative flex items-center w-full ${
          isFocused ? 'ring-2 ring-blue-500' : ''
        }`}
      >
        <div className="relative w-full">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            placeholder={placeholder}
            className={`w-full px-12 py-3 ${showInHeader ? 'py-2' : 'py-3'} bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full text-gray-800 dark:text-gray-200 focus:outline-none shadow-md transition-all duration-300`}
          />
          
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400">
            <FiSearch size={showInHeader ? 16 : 20} />
          </div>
          
          <AnimatePresence>
            {query && (
              <motion.button
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                type="button"
                onClick={clearSearch}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 focus:outline-none"
              >
                <FiX size={showInHeader ? 16 : 20} />
              </motion.button>
            )}
          </AnimatePresence>
        </div>
        
        {!showInHeader && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            type="submit"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full focus:outline-none transition-colors duration-300"
          >
            Search
          </motion.button>
        )}
      </motion.form>
      
      {/* Search results dropdown */}
      <AnimatePresence>
        {isFocused && query.length >= 2 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute z-50 w-full mt-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden"
          >
            {searchResults.length > 0 ? (
              <div className="max-h-96 overflow-y-auto">
                {searchResults.map((app) => (
                  <Link 
                    key={app.id} 
                    to={`/apps/${app.id}`}
                    onClick={() => setIsFocused(false)}
                    className="block hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <div className="flex items-center p-3 border-b border-gray-100 dark:border-gray-700 last:border-0">
                      <div className="w-12 h-12 rounded-md overflow-hidden mr-3">
                        <img src={app.image} alt={app.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 dark:text-white">{app.name}</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1">{app.description}</p>
                      </div>
                      <FiArrowRight className="text-gray-400" />
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="p-4 text-gray-500 dark:text-gray-400 text-sm text-center">
                No results found for "{query}"
              </div>
            )}
            
            {searchResults.length > 0 && (
              <div className="p-2 bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600">
                <button
                  onClick={handleSubmit}
                  className="w-full text-center text-sm text-blue-600 dark:text-blue-400 hover:underline py-1"
                >
                  View all {searchResults.length} results
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SearchComponent;
