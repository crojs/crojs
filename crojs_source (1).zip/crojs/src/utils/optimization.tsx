// This file contains optimization configurations for the Crojs website

// Image optimization helper
export const getOptimizedImageUrl = (url: string, width: number = 600): string => {
  // For placeholder images, we'll keep them as is
  if (url.includes('placeholder.com')) {
    return url;
  }
  
  // For real images, we would add width parameters or use an image optimization service
  // This is a placeholder implementation
  return `${url}?w=${width}&q=80`;
};

// Lazy loading helper for components
export const lazyLoadComponent = (importFunc: () => Promise<any>) => {
  const LazyComponent = React.lazy(importFunc);
  return (props: any) => (
    <React.Suspense fallback={<div className="p-4 text-center">Loading...</div>}>
      <LazyComponent {...props} />
    </React.Suspense>
  );
};

// SEO helper for page titles and descriptions
export const setSEO = (title: string, description: string) => {
  document.title = `${title} | Crojs - Download Premium Movie Apps`;
  
  // Update meta description
  const metaDescription = document.querySelector('meta[name="description"]');
  if (metaDescription) {
    metaDescription.setAttribute('content', description);
  }
};

// Performance optimization - debounce function for search
export const debounce = <F extends (...args: any[]) => any>(
  func: F,
  waitFor: number
) => {
  let timeout: ReturnType<typeof setTimeout> | null = null;

  const debounced = (...args: Parameters<F>) => {
    if (timeout !== null) {
      clearTimeout(timeout);
      timeout = null;
    }
    timeout = setTimeout(() => func(...args), waitFor);
  };

  return debounced as (...args: Parameters<F>) => ReturnType<F>;
};

// Accessibility helper - focus trap for modals
export const trapFocus = (element: HTMLElement) => {
  const focusableElements = element.querySelectorAll(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  
  const firstElement = focusableElements[0] as HTMLElement;
  const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;
  
  // Set focus to first element
  firstElement.focus();
  
  // Trap focus inside the element
  element.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
      if (e.shiftKey && document.activeElement === firstElement) {
        e.preventDefault();
        lastElement.focus();
      } else if (!e.shiftKey && document.activeElement === lastElement) {
        e.preventDefault();
        firstElement.focus();
      }
    }
  });
};

// Best practices - secure links helper
export const secureExternalLink = (url: string) => {
  return {
    href: url,
    target: "_blank",
    rel: "noopener noreferrer",
    "aria-label": `Visit ${new URL(url).hostname} (opens in a new tab)`
  };
};
