import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiArrowLeft } from 'react-icons/fi';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-20">
      <div className="container mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6">
          <FiArrowLeft className="mr-2" />
          <span>Back to Home</span>
        </Link>
        
        <div className="max-w-3xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6"
          >
            About Crojs
          </motion.h1>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 md:p-8">
              <div className="prose prose-blue max-w-none dark:prose-invert">
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                  Crojs is your ultimate destination for downloading premium movie streaming applications. 
                  We curate and provide access to the best movie apps available, ensuring you always have 
                  access to the latest entertainment content.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Our Mission</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                  Our mission is to simplify the process of finding and downloading high-quality movie 
                  streaming applications. We believe that everyone should have easy access to entertainment, 
                  and we work tirelessly to provide a seamless download experience.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">What We Offer</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                  At Crojs, we offer a carefully selected collection of movie streaming applications. 
                  Each app is thoroughly tested for quality, performance, and security before being added 
                  to our platform. We provide detailed information about each app, including features, 
                  ratings, and user reviews, to help you make informed decisions.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Our Commitment</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                  We are committed to providing a safe and secure download experience. All apps on our 
                  platform are regularly scanned for malware and other security threats. We also ensure 
                  that our website is optimized for performance, accessibility, and user experience.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Contact Us</h2>
                <p className="text-gray-700 dark:text-gray-300">
                  If you have any questions, suggestions, or feedback, please don't hesitate to 
                  <Link to="/contact" className="text-blue-600 hover:text-blue-700"> contact us</Link>. 
                  We value your input and are always looking for ways to improve our service.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
