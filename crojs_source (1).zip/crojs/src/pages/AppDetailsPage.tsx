import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiDownload, FiArrowLeft, FiStar, FiInfo, FiPackage, FiCode } from 'react-icons/fi';
import SectionTitle from '../components/ui/SectionTitle';
import { movieApps, AppData } from '../data/appData';

const AppDetailsPage: React.FC = () => {
  const { appId } = useParams<{ appId: string }>();
  const [app, setApp] = useState<AppData | null>(null);
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    const foundApp = movieApps.find(a => a.id === appId);
    if (foundApp) {
      setApp(foundApp);
    }
  }, [appId]);
  
  if (!app) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">App Not Found</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-8">The app you're looking for doesn't exist or has been removed.</p>
        <Link to="/">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg inline-flex items-center space-x-2"
          >
            <FiArrowLeft />
            <span>Back to Home</span>
          </motion.button>
        </Link>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-20">
      <div className="container mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6">
          <FiArrowLeft className="mr-2" />
          <span>Back to Home</span>
        </Link>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/3 relative">
              <img 
                src={app.image} 
                alt={app.name} 
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                {app.category}
              </div>
            </div>
            
            <div className="md:w-2/3 p-6 md:p-8">
              <div className="flex justify-between items-start">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{app.name}</h1>
                <div className="flex items-center bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-100 px-3 py-1 rounded-full">
                  <FiStar className="mr-1" />
                  <span>{app.rating.toFixed(1)}</span>
                </div>
              </div>
              
              <p className="text-gray-600 dark:text-gray-300 mb-6">{app.description}</p>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div className="flex items-center">
                  <FiPackage className="text-blue-600 mr-2" />
                  <div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">Size</div>
                    <div className="font-medium text-gray-900 dark:text-white">{app.size}</div>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <FiCode className="text-blue-600 mr-2" />
                  <div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">Version</div>
                    <div className="font-medium text-gray-900 dark:text-white">{app.version}</div>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <FiInfo className="text-blue-600 mr-2" />
                  <div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">Developer</div>
                    <div className="font-medium text-gray-900 dark:text-white">{app.developer}</div>
                  </div>
                </div>
              </div>
              
              <Link to={`/download/${app.id}`}>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg flex items-center justify-center space-x-3 transition-colors shadow-lg"
                >
                  <FiDownload size={20} />
                  <span className="font-medium">Download {app.name}</span>
                </motion.button>
              </Link>
            </div>
          </div>
          
          <div className="border-t border-gray-200 dark:border-gray-700 p-6 md:p-8">
            <SectionTitle title="About This App" />
            
            <div className="prose prose-blue max-w-none dark:prose-invert">
              <p className="text-gray-700 dark:text-gray-300 mb-6">{app.longDescription}</p>
              
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Features</h3>
              <ul className="space-y-2 mb-6">
                {app.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-blue-600 mr-2">•</span>
                    <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-12">
          <SectionTitle title="Similar Apps" />
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
            {movieApps
              .filter(a => a.id !== app.id && a.category === app.category)
              .slice(0, 4)
              .map(similarApp => (
                <Link key={similarApp.id} to={`/apps/${similarApp.id}`}>
                  <motion.div
                    whileHover={{ y: -10 }}
                    className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md"
                  >
                    <div className="relative pb-[56.25%]">
                      <img 
                        src={similarApp.image} 
                        alt={similarApp.name} 
                        className="absolute top-0 left-0 w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="p-4">
                      <h3 className="font-bold text-gray-900 dark:text-white mb-1">{similarApp.name}</h3>
                      <div className="flex items-center text-yellow-500 text-sm mb-2">
                        <FiStar className="mr-1" />
                        <span>{similarApp.rating.toFixed(1)}</span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">{similarApp.description}</p>
                    </div>
                  </motion.div>
                </Link>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppDetailsPage;
