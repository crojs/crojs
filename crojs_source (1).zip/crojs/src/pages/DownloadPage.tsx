import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiArrowLeft, FiDownload, FiCheck } from 'react-icons/fi';
import { DownloadButton, DownloadTimer } from '../components/ui/DownloadComponents';
import { movieApps } from '../data/appData';

const DownloadPage: React.FC = () => {
  const { appId } = useParams<{ appId: string }>();
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [seconds] = useState(Math.floor(Math.random() * 10) + 1); // Random 1-10 seconds
  
  const app = movieApps.find(a => a.id === appId);
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  if (!app) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">App Not Found</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-8">The app you're looking for doesn't exist or has been removed.</p>
        <Link to="/">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg inline-flex items-center space-x-2"
          >
            <FiArrowLeft />
            <span>Back to Home</span>
          </motion.button>
        </Link>
      </div>
    );
  }
  
  const handleDownloadClick = () => {
    setCountdown(true);
  };
  
  const handleTimerComplete = () => {
    setCountdown(false);
    setProcessing(true);
    
    // Simulate download processing
    setTimeout(() => {
      setProcessing(false);
      setCompleted(true);
    }, 3000);
  };
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-20">
      <div className="container mx-auto px-4 py-8">
        <Link to={`/apps/${appId}`} className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6">
          <FiArrowLeft className="mr-2" />
          <span>Back to App Details</span>
        </Link>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 md:p-8">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 rounded-xl overflow-hidden mr-4">
                  <img src={app.image} alt={app.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{app.name}</h1>
                  <p className="text-gray-600 dark:text-gray-300">Version {app.version} • {app.size}</p>
                </div>
              </div>
              
              {!countdown && !processing && !completed && (
                <div className="space-y-6">
                  <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-4">
                    <h3 className="font-medium text-blue-800 dark:text-blue-300 mb-2">Download Information</h3>
                    <p className="text-blue-700 dark:text-blue-400 text-sm">
                      You are about to download {app.name}. Click the button below to start the download process.
                    </p>
                  </div>
                  
                  <DownloadButton appName={app.name} onClick={handleDownloadClick} />
                </div>
              )}
              
              {(countdown || processing) && (
                <DownloadTimer 
                  seconds={seconds} 
                  onComplete={handleTimerComplete} 
                  isProcessing={processing} 
                />
              )}
              
              {completed && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-8"
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full mb-4">
                    <FiCheck className="text-green-600 dark:text-green-400" size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Download Complete!</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    Your download of {app.name} has been completed successfully.
                  </p>
                  <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => navigate('/')}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
                    >
                      Back to Home
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => {
                        setCompleted(false);
                        setCountdown(false);
                        setProcessing(false);
                      }}
                      className="bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-white px-6 py-3 rounded-lg transition-colors"
                    >
                      Download Again
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 p-6 md:p-8">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Installation Instructions</h3>
              <ol className="space-y-3 text-gray-700 dark:text-gray-300">
                <li className="flex">
                  <span className="font-bold mr-2">1.</span>
                  <span>Once the download is complete, locate the APK file in your downloads folder.</span>
                </li>
                <li className="flex">
                  <span className="font-bold mr-2">2.</span>
                  <span>Tap on the APK file to begin installation. You may need to enable installation from unknown sources in your device settings.</span>
                </li>
                <li className="flex">
                  <span className="font-bold mr-2">3.</span>
                  <span>Follow the on-screen instructions to complete the installation.</span>
                </li>
                <li className="flex">
                  <span className="font-bold mr-2">4.</span>
                  <span>Once installed, open the app and enjoy your content!</span>
                </li>
              </ol>
            </div>
          </div>
          
          <div className="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 md:p-8">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Troubleshooting</h3>
              <div className="space-y-4 text-gray-700 dark:text-gray-300">
                <div>
                  <h4 className="font-medium mb-1">Download not starting?</h4>
                  <p className="text-sm">Try refreshing the page or clicking the download button again.</p>
                </div>
                <div>
                  <h4 className="font-medium mb-1">Installation failed?</h4>
                  <p className="text-sm">Make sure you have enabled installation from unknown sources in your device settings.</p>
                </div>
                <div>
                  <h4 className="font-medium mb-1">App not working?</h4>
                  <p className="text-sm">Check if your device meets the minimum requirements or try downloading an older version.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DownloadPage;
