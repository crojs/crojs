import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import HeroSection from '../components/ui/HeroSection';
import SearchComponent from '../components/ui/SearchComponent';
import SectionTitle from '../components/ui/SectionTitle';
import AppCard from '../components/ui/AppCard';
import { movieApps } from '../data/appData';

const HomePage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredApps, setFilteredApps] = useState(movieApps);
  const location = useLocation();
  
  useEffect(() => {
    // Check for search query in URL
    const params = new URLSearchParams(location.search);
    const query = params.get('search');
    
    if (query) {
      handleSearch(query);
    }
  }, [location.search]);
  
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    
    if (!query.trim()) {
      setFilteredApps(movieApps);
      return;
    }
    
    const filtered = movieApps.filter(app => 
      app.name.toLowerCase().includes(query.toLowerCase()) ||
      app.description.toLowerCase().includes(query.toLowerCase()) ||
      app.category.toLowerCase().includes(query.toLowerCase()) ||
      app.developer.toLowerCase().includes(query.toLowerCase()) ||
      app.features.some(feature => feature.toLowerCase().includes(query.toLowerCase()))
    );
    
    setFilteredApps(filtered);
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <HeroSection
        title="Download Premium Movie Apps"
        subtitle="Access the best movie streaming applications all in one place. High-quality, ad-free, and always updated."
      >
        <div className="mt-8">
          <SearchComponent onSearch={handleSearch} />
        </div>
      </HeroSection>
      
      <div className="container mx-auto px-4 py-16">
        <SectionTitle
          title="Popular Movie Apps"
          subtitle="Discover and download the most popular movie streaming applications"
          centered
        />
        
        {searchQuery && (
          <div className="mb-8 text-center">
            <p className="text-gray-600 dark:text-gray-300">
              {filteredApps.length === 0 
                ? `No results found for "${searchQuery}"` 
                : `Showing ${filteredApps.length} results for "${searchQuery}"`}
            </p>
          </div>
        )}
        
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {filteredApps.map(app => (
            <AppCard
              key={app.id}
              id={app.id}
              name={app.name}
              description={app.description}
              image={app.image}
              category={app.category}
              rating={app.rating}
            />
          ))}
        </motion.div>
        
        {filteredApps.length === 0 && (
          <div className="text-center py-16">
            <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-300 mb-2">No apps found</h3>
            <p className="text-gray-500 dark:text-gray-400">Try adjusting your search criteria</p>
          </div>
        )}
      </div>
      
      <div className="bg-gray-100 dark:bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <SectionTitle
            title="Why Choose Crojs?"
            subtitle="We provide the best movie app download experience with premium features and support"
            centered
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <motion.div
              whileHover={{ y: -10 }}
              className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md"
            >
              <div className="text-blue-600 text-4xl mb-4">🔍</div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Curated Selection</h3>
              <p className="text-gray-600 dark:text-gray-300">
                We carefully select and test each app to ensure quality and performance.
              </p>
            </motion.div>
            
            <motion.div
              whileHover={{ y: -10 }}
              className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md"
            >
              <div className="text-blue-600 text-4xl mb-4">🚀</div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Fast Downloads</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Our optimized servers provide the fastest download speeds possible.
              </p>
            </motion.div>
            
            <motion.div
              whileHover={{ y: -10 }}
              className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md"
            >
              <div className="text-blue-600 text-4xl mb-4">🔒</div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Safe & Secure</h3>
              <p className="text-gray-600 dark:text-gray-300">
                All apps are verified and scanned for malware before being added to our platform.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-16">
        <SectionTitle
          title="Latest Updates"
          subtitle="Stay up to date with the newest versions and features"
          centered
        />
        
        <div className="mt-8 bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="space-y-4">
              {movieApps.slice(0, 5).map((app, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between border-b border-gray-100 dark:border-gray-700 pb-4 last:border-0 last:pb-0"
                >
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-lg overflow-hidden mr-4">
                      <img src={app.image} alt={app.name} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">{app.name}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Version {app.version}</p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Updated: {new Date().toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
