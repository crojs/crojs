import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiArrowLeft, FiPlus, FiMinus } from 'react-icons/fi';

const FaqPage: React.FC = () => {
  const faqs = [
    {
      question: 'What is Crojs?',
      answer: 'Crojs is a platform that provides access to premium movie streaming applications. We curate and offer a selection of the best movie apps available, making it easy for users to discover and download high-quality entertainment apps.'
    },
    {
      question: 'Are the apps on Crojs free to download?',
      answer: 'Yes, all apps on Crojs are free to download. However, some apps may offer in-app purchases or premium features that require payment.'
    },
    {
      question: 'How do I install the apps after downloading?',
      answer: 'After downloading an app, locate the APK file in your downloads folder. Tap on it to begin installation. You may need to enable installation from unknown sources in your device settings. Follow the on-screen instructions to complete the installation.'
    },
    {
      question: 'Are the apps safe to use?',
      answer: 'We thoroughly test all apps for security and performance before adding them to our platform. However, we recommend using a VPN and being cautious about the content you access through these apps.'
    },
    {
      question: 'Why is my download not starting?',
      answer: 'If your download is not starting, try refreshing the page or clicking the download button again. If the issue persists, check your internet connection or try using a different browser.'
    },
    {
      question: 'Can I use these apps on iOS devices?',
      answer: 'Most of the apps on our platform are designed for Android devices. iOS users may have limited options due to Apple\'s restrictions on app installations outside the App Store.'
    },
    {
      question: 'How often are the apps updated?',
      answer: 'We strive to provide the latest versions of all apps. Updates are typically released when developers make changes or improvements to their applications. Check back regularly for the most recent versions.'
    },
    {
      question: 'What should I do if an app is not working?',
      answer: 'If an app is not working, first ensure your device meets the minimum requirements. Try restarting the app or your device. If issues persist, you can download an older version of the app or contact us for assistance.'
    },
    {
      question: 'Do I need a VPN to use these apps?',
      answer: 'While not strictly required, we recommend using a VPN for privacy and to access geo-restricted content. A VPN can also help prevent ISP throttling when streaming.'
    },
    {
      question: 'How can I request an app to be added to Crojs?',
      answer: 'If you\'d like to suggest an app for inclusion on our platform, please use our contact form to submit your request. We appreciate user suggestions and regularly evaluate new apps to add to our collection.'
    }
  ];
  
  const FaqItem = ({ question, answer, index }: { question: string; answer: string; index: number }) => {
    const [isOpen, setIsOpen] = React.useState(false);
    
    return (
      <div className="border-b border-gray-200 dark:border-gray-700 last:border-0">
        <button
          className="flex justify-between items-center w-full py-4 text-left focus:outline-none"
          onClick={() => setIsOpen(!isOpen)}
        >
          <span className="text-lg font-medium text-gray-900 dark:text-white">{question}</span>
          <span className="ml-6 flex-shrink-0 text-gray-500 dark:text-gray-400">
            {isOpen ? <FiMinus size={20} /> : <FiPlus size={20} />}
          </span>
        </button>
        
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="pb-4 text-gray-600 dark:text-gray-300"
          >
            <p>{answer}</p>
          </motion.div>
        )}
      </div>
    );
  };
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-20">
      <div className="container mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6">
          <FiArrowLeft className="mr-2" />
          <span>Back to Home</span>
        </Link>
        
        <div className="max-w-3xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6"
          >
            Frequently Asked Questions
          </motion.h1>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 md:p-8">
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                Find answers to the most common questions about Crojs and our movie streaming applications.
                If you can't find what you're looking for, feel free to contact us.
              </p>
              
              <div className="mt-8">
                {faqs.map((faq, index) => (
                  <FaqItem 
                    key={index} 
                    question={faq.question} 
                    answer={faq.answer} 
                    index={index} 
                  />
                ))}
              </div>
            </div>
          </div>
          
          <div className="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 md:p-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Still Have Questions?</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                If you couldn't find the answer to your question, please don't hesitate to reach out to us.
                We're here to help!
              </p>
              <Link to="/contact">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
                >
                  Contact Us
                </motion.button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FaqPage;
